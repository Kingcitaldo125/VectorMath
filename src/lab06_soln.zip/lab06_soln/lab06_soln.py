import pygame

# @@@@ FUNCTIONS @@@@ #
def getPixelHoriz(surf, relative_value):
    """ relative_value is a float in the range [0.0...1.0] indicating a
        PERCENTAGE of the screen horizontally.  This could be either an
        x-coordinate or a width value.  The function returns the pixel
        amount (x-coordinate or width) using surf's dimensions """
    #return

def getPixelSizes(surf, left, top, horiz, vert):
    leftX = int(left * surf.get_width())
    topY = int(top * surf.get_height())
    width = int(surf.get_width() * horiz)
    height = int(surf.get_height() * vert)
    return leftX, topY, width, height

def drawBorder(surf, borderImg, left, top, horiz, vert):
    leftX, topY, cwidth, cheight = getPixelSizes(surf, left, top, horiz, vert)
    surf.blit(borderImg, (leftX - 9, topY - 9), (0,0,9,9))
    surf.blit(borderImg, (leftX - 9, topY + cheight), (0,12,9,9))
    surf.blit(borderImg, (leftX + cwidth, topY - 9), (233,0,9,9))
    surf.blit(borderImg, (leftX + cwidth, topY + cheight), (233,12,9,9))
    tempS = pygame.Surface((9,1))
    tempS.blit(borderImg, (0,0), (0,10,9,1))
    tempS = pygame.transform.scale(tempS, (9, cheight))
    surf.blit(tempS, (leftX - 9,topY))
    surf.blit(tempS, (leftX + cwidth,topY))
    tempS = pygame.Surface((224,9))
    tempS.blit(borderImg, (0,0), (10,0,224,9))
    tempS = pygame.transform.scale(tempS, (cwidth, 9))
    surf.blit(tempS, (leftX, topY - 9))
    surf.blit(tempS, (leftX, topY + cheight))


def drawPalette(surf, borderImg, cur_red, cur_green, cur_blue, left, top, horiz, vert):
    leftX, topY, cwidth, cheight = getPixelSizes(surf, left, top, horiz, vert)
    inc = 255 / cwidth
    x = leftX
    red = 0
    green = 0
    blue = 0
    redX = int(cur_red / 255 * cwidth)
    greenX = int(cur_green / 255 * cwidth)
    blueX = int(cur_blue / 255 * cwidth)
    section_height = int(cheight / 3)
    while x < leftX + cwidth:
        red += inc
        green += inc
        blue += inc
        if x - leftX == redX:   color = (255,255,255)
        else:                   color = (red,0,0)
        pygame.draw.line(surf, color, (x,topY+0), (x,topY+section_height))
        if x - leftX == greenX: color = (255,255,255)
        else:                   color = (0,green,0)
        pygame.draw.line(surf, color, (x,topY+section_height), (x,topY+section_height*2))
        if x - leftX == blueX:  color = (255,255,255)
        else:                   color = (0,0,blue)
        pygame.draw.line(surf, color, (x,topY+section_height*2), (x,topY+section_height*3))
        x += 1
    drawBorder(surf, borderImg, left, top, horiz, vert)

def getPaletteColor(surf, cur_red, cur_green, cur_blue, x, y, left, top, horiz, vert):
    leftX, topY, cwidth, cheight = getPixelSizes(surf, left, top, horiz, vert)
    section_height = int(cheight / 3)
    if y - topY >= 0 and y - topY < section_height:
        # Changing red
        cur_red = int(255 * (x - leftX) / cwidth)
    elif y - topY >= section_height and y - topY < section_height * 2:
        # Changing gree
        cur_green = int(255 * (x - leftX) / cwidth)
    else:
        # Changind blue
        cur_blue = int(255 * (x - leftX) / cwidth)
    return cur_red, cur_green, cur_blue

def pointInRectangle(x, y, leftX, topY, width, height):
    if x >= leftX and x < leftX + width and y >= topY and y < topY + height:
        return True
    return False

def ptInRectangle(surf, pt_relative_x, pt_relative_y, relative_x, relative_y, relative_w, relative_h):
    leftX, topY, width, height = getPixelSizes(surf, relative_x, relative_y, relative_w, relative_h)
    ptX = pt_relative_x * surf.get_width()
    ptY = pt_relative_y * surf.get_height()
    if ptX >= leftX and ptX < leftX + width and ptY >= topY and ptY < topY + height:
        return True
    return False


def drawButton(surf, borderImg, fontObj, text, leftX, topY, width, height, highlighted):
    left, top, cwidth, cheight = getPixelSizes(surf, leftX, topY, width, height)
    drawBorder(surf, borderImg, leftX, topY, width, height)
    if highlighted:
        bcolor = (100,100,0)
        fcolor = (0,0,0)
    else:
        bcolor = (0,0,0)
        fcolor = (255,255,0)
    tempS = fontObj.render(text, True, fcolor)
    pygame.draw.rect(surf, bcolor, (left,top,cwidth,cheight))
    surf.blit(tempS, (left + cwidth / 2 - tempS.get_width() / 2, top + cheight / 2 - tempS.get_height() / 2))

# @@@@ MAIN PROGRAM @@@@ #
pygame.display.init()
pygame.font.init()

canvas_left = 0.05
canvas_top = 0.05
canvas_horiz = 0.65
canvas_vert = 0.9

palette_left = 0.75
palette_top = 0.75
palette_horiz = 0.2
palette_vert = 0.2

swatch_left = 0.8
swatch_top = 0.55
swatch_horiz = 0.1
swatch_vert = 0.1

brushRed = 128
brushGreen = 64
brushBlue = 99
brushSize = 10

quit_left = 0.85
quit_top = 0.05
quit_horiz = 0.1
quit_vert = 0.05

save_left = quit_left
save_top = quit_top + 0.1
save_horiz = quit_horiz
save_vert = quit_vert

fill_left = quit_left
fill_top = save_top + 0.1
fill_horiz = quit_horiz
fill_vert = quit_vert

highlighted_button = None

min_width = 400
min_height = 300
screen = pygame.display.set_mode((800,600), pygame.RESIZABLE)
canvas = pygame.Surface((screen.get_width() * canvas_horiz, screen.get_height() * canvas_vert))
# Corners are 9 x 9 pixels.
borderImg = pygame.image.load("borders.png").convert_alpha()
font = pygame.font.SysFont("Times New Roman", 20)
done = False

while not done:
    # @@@@ UPDATE @@@@ #

    # @@@@ GET INPUT @@@@ #
    if pygame.event.peek(pygame.VIDEORESIZE):
        evt = pygame.event.get(pygame.VIDEORESIZE)[0]
        print(evt)
        screen = pygame.display.set_mode((max(evt.w, min_width), max(evt.h, min_height)), pygame.RESIZABLE)
        new_width = int(screen.get_width() * canvas_horiz)
        new_height = int(screen.get_height() * canvas_vert)
        canvas = pygame.transform.smoothscale(canvas, (new_width, new_height))
    pygame.event.get()
    pressedKeys = pygame.key.get_pressed()
    if pressedKeys[pygame.K_ESCAPE]:
        done = True
    mx, my = pygame.mouse.get_pos()
    mousePressed = pygame.mouse.get_pressed()
    mRelX = mx / screen.get_width()
    mRelY = my / screen.get_height()
    if mousePressed[0]:
        if ptInRectangle(screen, mRelX, mRelY, palette_left, palette_top, palette_horiz, palette_vert):
            brushRed, brushGreen, brushBlue = getPaletteColor(screen, brushRed, brushGreen, brushBlue, mx, my, palette_left, palette_top, palette_horiz, palette_vert)
        if ptInRectangle(screen, mRelX, mRelY, canvas_left, canvas_top, canvas_horiz, canvas_vert):
            leftX, topY, width, height = getPixelSizes(screen, canvas_left, canvas_top, canvas_horiz, canvas_vert)
            pygame.draw.circle(canvas, (brushRed, brushGreen, brushBlue), (mx - leftX, my - topY), brushSize)

    highlighted_button = None
    if ptInRectangle(screen, mRelX, mRelY, quit_left, quit_top, quit_horiz, quit_vert):
        if mousePressed[0]:
            done = True
        highlighted_button = "QUIT"
    elif ptInRectangle(screen, mRelX, mRelY, save_left, save_top, save_horiz, save_vert):
        if mousePressed[0]:
            pygame.image.save(canvas, "output.bmp")
        highlighted_button = "SAVE"
    elif ptInRectangle(screen, mRelX, mRelY, fill_left, fill_top, fill_horiz, fill_vert):
        if mousePressed[0]:
            canvas.fill((brushRed,brushGreen,brushBlue))
        highlighted_button = "FILL"

    # @@@@ DRAW @@@@ #
    screen.fill((127,128,128))
    leftX, topY, width, height = getPixelSizes(screen, canvas_left, canvas_top, canvas_horiz, canvas_vert)
    screen.blit(canvas, (leftX, topY))
    drawBorder(screen, borderImg, canvas_left, canvas_top, canvas_horiz, canvas_vert)
    drawPalette(screen, borderImg, brushRed, brushGreen, brushBlue, palette_left, palette_top, palette_horiz, palette_vert)
    pygame.draw.rect(screen, (brushRed, brushGreen, brushBlue), getPixelSizes(screen, swatch_left, swatch_top, swatch_horiz, swatch_vert))
    drawBorder(screen, borderImg, swatch_left, swatch_top, swatch_horiz, swatch_vert)
    drawButton(screen, borderImg, font, "QUIT", quit_left, quit_top, quit_horiz, quit_vert, highlighted_button == "QUIT")
    drawButton(screen, borderImg, font, "SAVE", save_left, save_top, save_horiz, save_vert, highlighted_button == "SAVE")
    drawButton(screen, borderImg, font, "FILL", fill_left, fill_top, fill_horiz, fill_vert, highlighted_button == "FILL")
    pygame.display.flip()

pygame.display.quit()